'use client';

import { useState } from 'react';
import { ArrowRightLeft, Package, Check, X, Clock, QrCode } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { type UserRole } from '@/lib/mock-data';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';

interface TransferRequestsProps {
  currentRole: UserRole;
}

export function TransferRequests({ currentRole }: TransferRequestsProps) {
  const { transferRequests, parcels, users, collectionPoints, updateTransferRequestStatus, updateParcelStatus, assignParcelToVehicle } = useStore();
  const [isAcceptDialogOpen, setIsAcceptDialogOpen] = useState(false);
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(null);

  const getUser = (userId: string) => users.find((u) => u.id === userId);
  const getPoint = (pointId: string) => collectionPoints.find((p) => p.id === pointId);
  const getParcel = (parcelId: string) => parcels.find((p) => p.id === parcelId);

  const pendingRequests = transferRequests.filter((r) => r.status === 'PENDING');
  const processedRequests = transferRequests.filter((r) => r.status !== 'PENDING');

  const handleAccept = () => {
    if (selectedRequestId) {
      const request = transferRequests.find((r) => r.id === selectedRequestId);
      if (request) {
        // Update request status
        updateTransferRequestStatus(selectedRequestId, 'ACCEPTED');
        
        // Update each parcel to IN_TRANSIT and assign to vehicle
        const transporter = getUser(request.transporterId);
        const transporterVehicle = transporter?.assignedVehicleId;
        
        request.parcelIds.forEach((parcelId) => {
          updateParcelStatus(
            parcelId,
            'IN_TRANSIT',
            request.transporterId,
            transporter?.name || 'Transporteur',
            'Transfert accepte',
            transporterVehicle
          );
          if (transporterVehicle) {
            assignParcelToVehicle(parcelId, transporterVehicle);
          }
        });
      }
      setSelectedRequestId(null);
      setIsAcceptDialogOpen(false);
    }
  };

  const handleReject = () => {
    if (selectedRequestId) {
      updateTransferRequestStatus(selectedRequestId, 'REJECTED');
      setSelectedRequestId(null);
      setIsRejectDialogOpen(false);
    }
  };

  const openAcceptDialog = (requestId: string) => {
    setSelectedRequestId(requestId);
    setIsAcceptDialogOpen(true);
  };

  const openRejectDialog = (requestId: string) => {
    setSelectedRequestId(requestId);
    setIsRejectDialogOpen(true);
  };

  const selectedRequest = selectedRequestId ? transferRequests.find((r) => r.id === selectedRequestId) : null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Demandes de Prise en Charge</h2>
        <p className="text-muted-foreground">
          {currentRole === 'COLLECTOR'
            ? 'Validez les demandes de transfert des transporteurs'
            : currentRole === 'TRANSPORTER'
            ? 'Vos demandes de recuperation de colis'
            : 'Suivi de toutes les demandes de transfert'}
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/20">
              <Clock className="h-5 w-5 text-warning" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{pendingRequests.length}</p>
              <p className="text-xs text-muted-foreground">En attente</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/20">
              <Check className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {transferRequests.filter((r) => r.status === 'ACCEPTED').length}
              </p>
              <p className="text-xs text-muted-foreground">Acceptees</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/20">
              <X className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {transferRequests.filter((r) => r.status === 'REJECTED').length}
              </p>
              <p className="text-xs text-muted-foreground">Rejetees</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Requests Table */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground">Demandes en attente</h3>
        <Card className="border-border bg-card">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="text-muted-foreground">ID</TableHead>
                  <TableHead className="text-muted-foreground">Transporteur</TableHead>
                  <TableHead className="text-muted-foreground">Point de collecte</TableHead>
                  <TableHead className="text-muted-foreground">Colis</TableHead>
                  <TableHead className="text-muted-foreground">Date</TableHead>
                  <TableHead className="text-muted-foreground">Statut</TableHead>
                  {currentRole === 'COLLECTOR' && (
                    <TableHead className="text-right text-muted-foreground">Actions</TableHead>
                  )}
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingRequests.map((request) => {
                  const transporter = getUser(request.transporterId);
                  const point = getPoint(request.collectionPointId);
                  const requestParcels = request.parcelIds.map((id) => getParcel(id)).filter(Boolean);

                  return (
                    <TableRow key={request.id} className="border-border">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
                            <ArrowRightLeft className="h-4 w-4 text-primary" />
                          </div>
                          <span className="font-mono font-medium text-foreground">
                            #{request.id.split('-')[1]}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {transporter && (
                            <>
                              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                                {transporter.avatar}
                              </div>
                              <span className="text-foreground">{transporter.name}</span>
                            </>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-foreground">{point?.name}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {requestParcels.map((parcel) => (
                            <span
                              key={parcel?.id}
                              className="rounded bg-secondary px-2 py-0.5 text-xs font-medium text-foreground"
                            >
                              {parcel?.trackingNumber}
                            </span>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {request.createdAt.toLocaleDateString('fr-FR')}
                      </TableCell>
                      <TableCell>
                        <span className="rounded-lg bg-warning/20 px-2 py-1 text-xs font-medium text-warning">
                          En attente
                        </span>
                      </TableCell>
                      {currentRole === 'COLLECTOR' && (
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="gap-1 border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                              onClick={() => openRejectDialog(request.id)}
                            >
                              <X className="h-4 w-4" />
                              Rejeter
                            </Button>
                            <Button
                              size="sm"
                              className="gap-1 bg-success text-success-foreground hover:bg-success/90"
                              onClick={() => openAcceptDialog(request.id)}
                            >
                              <QrCode className="h-4 w-4" />
                              Accepter
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  );
                })}
                {pendingRequests.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={currentRole === 'COLLECTOR' ? 7 : 6} className="h-24 text-center">
                      <div className="flex flex-col items-center gap-2">
                        <Check className="h-8 w-8 text-success" />
                        <p className="font-medium text-foreground">Aucune demande en attente</p>
                        <p className="text-sm text-muted-foreground">Toutes les demandes ont ete traitees</p>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* History Table */}
      {processedRequests.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">Historique</h3>
          <Card className="border-border bg-card">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="text-muted-foreground">ID</TableHead>
                    <TableHead className="text-muted-foreground">Transporteur</TableHead>
                    <TableHead className="text-muted-foreground">Point</TableHead>
                    <TableHead className="text-muted-foreground">Colis</TableHead>
                    <TableHead className="text-muted-foreground">Statut</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {processedRequests.map((request) => {
                    const transporter = getUser(request.transporterId);
                    const point = getPoint(request.collectionPointId);

                    return (
                      <TableRow key={request.id} className="border-border opacity-75">
                        <TableCell className="font-mono text-foreground">
                          #{request.id.split('-')[1]}
                        </TableCell>
                        <TableCell className="text-foreground">{transporter?.name}</TableCell>
                        <TableCell className="text-muted-foreground">{point?.name}</TableCell>
                        <TableCell className="text-foreground">{request.parcelIds.length} colis</TableCell>
                        <TableCell>
                          <span
                            className={cn(
                              'rounded-lg px-2 py-1 text-xs font-medium',
                              request.status === 'ACCEPTED'
                                ? 'bg-success/20 text-success'
                                : 'bg-destructive/20 text-destructive'
                            )}
                          >
                            {request.status === 'ACCEPTED' ? 'Acceptee' : 'Rejetee'}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Accept Dialog */}
      <Dialog open={isAcceptDialogOpen} onOpenChange={setIsAcceptDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Accepter la demande</DialogTitle>
            <DialogDescription>
              Confirmez le transfert des colis au transporteur. Les colis passeront au statut EN_TRANSIT.
            </DialogDescription>
          </DialogHeader>
          {selectedRequest && (
            <div className="rounded-lg bg-secondary p-4">
              <p className="mb-2 text-sm font-medium text-muted-foreground">Colis concernes:</p>
              <div className="flex flex-wrap gap-2">
                {selectedRequest.parcelIds.map((id) => {
                  const parcel = getParcel(id);
                  return (
                    <div key={id} className="flex items-center gap-2 rounded bg-card px-3 py-1.5">
                      <Package className="h-4 w-4 text-primary" />
                      <span className="text-sm font-medium text-foreground">{parcel?.trackingNumber}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAcceptDialogOpen(false)}>Annuler</Button>
            <Button onClick={handleAccept} className="gap-2 bg-success text-success-foreground hover:bg-success/90">
              <Check className="h-4 w-4" />
              Confirmer le transfert
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Rejeter la demande</DialogTitle>
            <DialogDescription>
              Etes-vous sur de vouloir rejeter cette demande de transfert ?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={handleReject} className="gap-2">
              <X className="h-4 w-4" />
              Rejeter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
