'use client';

import { useState } from 'react';
import { Package, Check, X, AlertTriangle, QrCode } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { getStatusLabel, getStatusColor, type Parcel } from '@/lib/mock-data';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';

export function CollectorReception() {
  const { parcels, collectionPoints, updateParcelStatus, updatePointStock } = useStore();
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false);
  const [selectedParcel, setSelectedParcel] = useState<Parcel | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  // Parcels waiting to be received (CREATED status)
  const pendingParcels = parcels.filter((p) => p.status === 'CREATED');
  const receivedToday = parcels.filter((p) => p.status === 'RECEIVED_AT_COLLECTION_POINT').length;
  const rejectedTotal = parcels.filter((p) => p.status === 'REJECTED').length;

  const getPointName = (pointId: string) => {
    return collectionPoints.find((p) => p.id === pointId)?.name || pointId;
  };

  const handleValidate = (parcel: Parcel) => {
    updateParcelStatus(
      parcel.id,
      'RECEIVED_AT_COLLECTION_POINT',
      'collector-1',
      'Jean Bastos',
      getPointName(parcel.originPointId)
    );
    updatePointStock(parcel.originPointId, 1);
  };

  const handleReject = () => {
    if (selectedParcel) {
      updateParcelStatus(
        selectedParcel.id,
        'REJECTED',
        'collector-1',
        'Jean Bastos',
        getPointName(selectedParcel.originPointId)
      );
      setSelectedParcel(null);
      setRejectReason('');
      setIsRejectDialogOpen(false);
    }
  };

  const openRejectDialog = (parcel: Parcel) => {
    setSelectedParcel(parcel);
    setIsRejectDialogOpen(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Flux de Reception</h2>
        <p className="text-muted-foreground">
          Validez ou rejetez les colis soumis par les clients
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-warning/20">
              <Package className="h-5 w-5 text-warning" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{pendingParcels.length}</p>
              <p className="text-xs text-muted-foreground">En attente</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-success/20">
              <Check className="h-5 w-5 text-success" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{receivedToday}</p>
              <p className="text-xs text-muted-foreground">Valides</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-destructive/20">
              <X className="h-5 w-5 text-destructive" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{rejectedTotal}</p>
              <p className="text-xs text-muted-foreground">Rejetes</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Parcels Table */}
      <Card className="border-border bg-card">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">N° Suivi</TableHead>
                <TableHead className="text-muted-foreground">Client</TableHead>
                <TableHead className="text-muted-foreground">Poids</TableHead>
                <TableHead className="text-muted-foreground">Destination</TableHead>
                <TableHead className="text-muted-foreground">Statut</TableHead>
                <TableHead className="text-right text-muted-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingParcels.map((parcel) => (
                <TableRow key={parcel.id} className="border-border">
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/20">
                        <Package className="h-4 w-4 text-primary" />
                      </div>
                      <span className="font-mono font-medium text-foreground">
                        {parcel.trackingNumber}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-foreground">{parcel.senderName}</TableCell>
                  <TableCell className="text-foreground">{parcel.weight} kg</TableCell>
                  <TableCell className="text-muted-foreground">
                    {getPointName(parcel.destinationPointId)}
                  </TableCell>
                  <TableCell>
                    <span
                      className={cn(
                        'inline-block rounded-lg px-2 py-1 text-xs font-medium',
                        getStatusColor(parcel.status)
                      )}
                    >
                      {getStatusLabel(parcel.status)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1 border-destructive/50 text-destructive hover:bg-destructive hover:text-destructive-foreground"
                        onClick={() => openRejectDialog(parcel)}
                      >
                        <AlertTriangle className="h-4 w-4" />
                        Rejeter
                      </Button>
                      <Button
                        size="sm"
                        className="gap-1 bg-success text-success-foreground hover:bg-success/90"
                        onClick={() => handleValidate(parcel)}
                      >
                        <Check className="h-4 w-4" />
                        Valider
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {pendingParcels.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="h-24 text-center">
                    <div className="flex flex-col items-center gap-2">
                      <Check className="h-8 w-8 text-success" />
                      <p className="font-medium text-foreground">Tous les colis sont traites</p>
                      <p className="text-sm text-muted-foreground">Aucun colis en attente de validation</p>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Rejeter le colis</DialogTitle>
            <DialogDescription>
              Vous allez rejeter le colis {selectedParcel?.trackingNumber}. Veuillez indiquer le motif du rejet.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <label className="mb-2 block text-sm font-medium text-foreground">Motif du rejet</label>
            <Textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Colis endommage, poids incorrect, emballage non conforme..."
              className="bg-secondary min-h-[100px]"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>Annuler</Button>
            <Button variant="destructive" onClick={handleReject} className="gap-2">
              <AlertTriangle className="h-4 w-4" />
              Confirmer le rejet
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
